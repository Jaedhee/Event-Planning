import React from 'react';
import { motion } from 'framer-motion';

const Home = () => {
  return (
    <div>
      <section className="bg-cover bg-center h-96 text-white flex items-center justify-center" style={{ backgroundImage: 'url(/assets/images/hero.jpg)' }}>
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 1 }}>
          <h1 className="text-4xl font-bold">Plan Your Dream Event</h1>
          <p className="text-lg mt-2">Elegant. Memorable. Seamless.</p>
        </motion.div>
      </section>
      <section className="py-12 px-4">
        <h2 className="text-2xl font-semibold text-center mb-8">Our Services</h2>
        <div className="grid md:grid-cols-3 gap-6">
          {['Weddings', 'Corporate Events', 'Photo & Video'].map((service, index) => (
            <motion.div key={index} className="bg-white p-6 shadow-lg rounded-xl text-center"
              whileHover={{ scale: 1.05 }}
              transition={{ type: 'spring', stiffness: 300 }}
            >
              <h3 className="text-xl font-bold mb-2">{service}</h3>
              <p className="text-gray-600">High quality planning and coordination for your special day.</p>
            </motion.div>
          ))}
        </div>
      </section>
    </div>
  );
};

export default Home;
