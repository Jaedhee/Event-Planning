const Footer = () => (
  <footer className="bg-gray-800 text-white py-6 mt-12">
    <div className="max-w-7xl mx-auto px-4 flex justify-between items-center">
      <p>&copy; {new Date().getFullYear()} Eventify. All rights reserved.</p>
      <div className="space-x-4">
        <a href="#" className="hover:underline">Instagram</a>
        <a href="#" className="hover:underline">Facebook</a>
      </div>
    </div>
  </footer>
);

export default Footer;
