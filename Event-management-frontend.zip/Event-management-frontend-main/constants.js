const BASE_URL = 'https://event-planner-json-server.herokuapp.com';

export default BASE_URL;
